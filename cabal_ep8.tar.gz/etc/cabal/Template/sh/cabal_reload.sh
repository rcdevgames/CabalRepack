#!/bin/sh

echo -e "Reloading GlobalDBAgent..." && systemctl reload GlobalDBAgent && sleep 1
echo -e "Reloading AuthDBAgent..." && systemctl reload AuthDBAgent && sleep 1
echo -e "Reloading CashDBAgent..." && systemctl reload CashDBAgent && sleep 1
echo -e "Reloading EventDBAgent..." && systemctl reload EventDBAgent && sleep 1
echo -e "Reloading PCBangDBAgent..." && systemctl reload PCBangDBAgent && sleep 1
echo -e "Reloading DBAgent*..." && systemctl reload DBAgent* && sleep 1
echo -e "Reloading RockAndRollITS..." && systemctl reload RockAndRollITS && sleep 1
echo -e "Reloading GlobalMgrSvr..." && systemctl reload GlobalMgrSvr && sleep 1
echo -e "Reloading PartySvr*..." && systemctl reload PartySvr* && sleep 1
echo -e "Reloading ChatNode*..." && systemctl reload ChatNode* && sleep 1
echo -e "Reloading EventMgrSvr..." && systemctl reload EventMgrSvr && sleep 1
echo -e "Reloading LoginSvr*..." && systemctl reload LoginSvr* && sleep 1
echo -e "Reloading AgentShop*..." && systemctl reload AgentShop* && sleep 1
echo -e "Reloading WorldSvr*..." && systemctl reload WorldSvr* && sleep 1
