#!/bin/sh

echo -e "Stopping GlobalDBAgent..." && systemctl stop GlobalDBAgent && sleep 1
echo -e "Stopping AuthDBAgent..." && systemctl stop AuthDBAgent && sleep 1
echo -e "Stopping CashDBAgent..." && systemctl stop CashDBAgent && sleep 1
echo -e "Stopping EventDBAgent..." && systemctl stop EventDBAgent && sleep 1
echo -e "Stopping PCBangDBAgent..." && systemctl stop PCBangDBAgent && sleep 1
echo -e "Stopping DBAgent*..." && systemctl stop DBAgent* && sleep 1
echo -e "Stopping RockAndRollITS..." && systemctl stop RockAndRollITS && sleep 1
echo -e "Stopping GlobalMgrSvr..." && systemctl stop GlobalMgrSvr && sleep 1
echo -e "Stopping PartySvr*..." && systemctl stop PartySvr* && sleep 1
echo -e "Stopping ChatNode*..." && systemctl stop ChatNode* && sleep 1
echo -e "Stopping EventMgrSvr..." && systemctl stop EventMgrSvr && sleep 1
echo -e "Stopping LoginSvr*..." && systemctl stop LoginSvr* && sleep 1
echo -e "Stopping AgentShop*..." && systemctl stop AgentShop* && sleep 1
echo -e "Stopping WorldSvr*..." && systemctl stop WorldSvr* && sleep 1
