#!/bin/sh

RED='\033[0;31m'
NC='\033[0m'
type=$1
num=$2
idx=$3

if [ -z "$type" ] || [ -z "$num" ] || [[ $type != "-s" ]] && [[ $type != "-c" ]]
then
  echo -e "USAGE: ${0} [type] [count] [server_idx]"
  echo -e "Type    Usage"
  echo -e "-s      server"
  echo -e "-c      channel"
  echo -e "\nserver_idx field is only required when creating channels!"
  exit
fi

if [[ $type == "-c" ]] && [[ -z $idx ]]
then
  echo -e "USAGE: ${0} [type] [count] [server_idx]"
  echo -e "Type    Usage"
  echo -e "-s      server"
  echo -e "-c      channel"
  echo -e "\nserver_idx field is only required when creating channels!"
  exit
fi

re='^[0-9]+$'
if ! [[ $num =~ $re ]]
then
  echo -e "ERROR: count must be a number!"
  exit
fi

if [[ $type == "-c" ]]
then
  if ! [[ $idx =~ $re ]]
  then
    echo -e "ERROR: server_idx must be a number!"
    exit
  fi
fi

typeName="unknown"

if [[ $type == "-s" ]]
then
  typeName="server"
elif [[ $type == "-c" ]]
then
  typeName="channel"
fi

echo -e "Server type: ${typeName}, count: ${num}."
echo -e "${RED}\nWARNING: This will replace old ${typeName}s!"
echo -e "${NC}Do you want to continue [Y/n]?"
read ready

if [[ -z $ready || $ready == "n" || $ready == "N" ]]
then
  exit
fi

echo -e "${RED}==> ${NC}Stopping any running server services..."
systemctl daemon-reexec
systemctl stop GlobalDBAgent
systemctl stop AuthDBAgent
systemctl stop CashDBAgent
systemctl stop EventDBAgent
systemctl stop PCBangDBAgent
systemctl stop RockAndRollITS
systemctl stop GlobalMgrSvr
systemctl stop EventMgrSvr
systemctl stop DBAgent*
systemctl stop PartySvr*
systemctl stop ChatNode*
systemctl stop LoginSvr*
systemctl stop AgentShop*

if [[ $type == "-c" ]]
then
  echo -e "${RED}==> ${NC}Cleanning up old files..."
  rm -rf /etc/systemd/system/WorldSvr*.service
  rm -rf /usr/bin/WorldSvr_*
  
  echo -e "${RED}==> ${NC}Creating server services..."
  for (( i=1; i<=$num; i++ ))
  do
    leadingZero=""

    if [ $i -lt 10 ]
    then
      leadingZero="0"
    fi
    
    if [ $idx -lt 10 ]
    then
      leadingZero2="0"
    else
      leadingZero2=""
    fi

    ln -sf /usr/bin/WorldSvr /usr/bin/WorldSvr_${leadingZero2}${idx}_${leadingZero}${i}
    chmod 0700 /usr/bin/WorldSvr_${leadingZero2}${idx}_${leadingZero}${i}

    sed /etc/cabal/Template/systemd/WorldSvr_x.service \
    -e "s/PartySvr_x/PartySvr_$leadingZero2$idx/g" \
    -e "s/DBAgent_x/DBAgent_$leadingZero2$idx/g" \
    -e "s/ChatNode_x/ChatNode_$leadingZero2$idx/g" \
    -e "s/AgentShop_x/AgentShop_$leadingZero2$idx/g" \
    -e "s/WorldSvr_x/WorldSvr_${leadingZero2}${idx}_${leadingZero}${i}/g" \
    > /etc/systemd/system/WorldSvr_${leadingZero2}${idx}_${leadingZero}${i}.service

    sed /etc/cabal/Template/conf/WorldSvr_x.ini \
    -e "s/server_idx/$idx/g" \
    -e "s/channel_idx/$i/g" \
    > /etc/cabal/WorldSvr_${leadingZero2}${idx}_${leadingZero}${i}.ini

    systemctl daemon-reexec
    systemctl enable WorldSvr_${leadingZero2}${idx}_${leadingZero}${i}
  done
  
  echo -e "\nDone! Don't forget to change database config with cabal_config ;)"
  exit
fi

systemctl daemon-reexec
systemctl disable GlobalDBAgent
systemctl disable AuthDBAgent
systemctl disable CashDBAgent
systemctl disable EventDBAgent
systemctl disable PCBangDBAgent
systemctl disable RockAndRollITS
systemctl disable GlobalMgrSvr
systemctl disable EventMgrSvr
systemctl disable DBAgent*
systemctl disable PartySvr*
systemctl disable ChatNode*
systemctl disable LoginSvr*
systemctl disable AgentShop*

echo -e "${RED}==> ${NC}Cleanning up old files..."
rm -rf /etc/systemd/system/GlobalDBAgent.service
rm -rf /etc/systemd/system/AuthDBAgent.service
rm -rf /etc/systemd/system/CashDBAgent.service
rm -rf /etc/systemd/system/EventDBAgent.service
rm -rf /etc/systemd/system/PCBangDBAgent.service
rm -rf /etc/systemd/system/RockAndRollITS.service
rm -rf /etc/systemd/system/GlobalMgrSvr.service
rm -rf /etc/systemd/system/EventMgrSvr.service
rm -rf /etc/systemd/system/DBAgent*.service
rm -rf /etc/systemd/system/PartySvr*.service
rm -rf /etc/systemd/system/ChatNode*.service
rm -rf /etc/systemd/system/LoginSvr*.service
rm -rf /etc/systemd/system/AgentShop*.service

rm -rf /etc/cabal/*.ini

rm -rf /usr/bin/AgentShop_*
rm -rf /usr/bin/ChatNode_*
rm -rf /usr/bin/DBAgent_*
rm -rf /usr/bin/LoginSvr_*
rm -rf /usr/bin/PartySvr_*

echo -e "${RED}==> ${NC}Creating symlinks and setting up permissions..."

ln -sf /usr/bin/DBAgent /usr/bin/GlobalDBAgent
ln -sf /usr/bin/DBAgent /usr/bin/CashDBAgent
ln -sf /usr/bin/DBAgent /usr/bin/EventDBAgent
ln -sf /usr/bin/DBAgent /usr/bin/PCBangDBAgent

chmod 0700 /usr/bin/GlobalDBAgent
chmod 0700 /usr/bin/AuthDBAgent
chmod 0700 /usr/bin/CashDBAgent
chmod 0700 /usr/bin/EventDBAgent
chmod 0700 /usr/bin/PCBangDBAgent
chmod 0700 /usr/bin/RockAndRollITS
chmod 0700 /usr/bin/GlobalMgrSvr
chmod 0700 /usr/bin/EventMgrSvr

echo -e "${RED}==> ${NC}Copying systemd service files..."
cp -rf /etc/cabal/Template/systemd/GlobalDBAgent.service /etc/systemd/system/
cp -rf /etc/cabal/Template/systemd/AuthDBAgent.service /etc/systemd/system/
cp -rf /etc/cabal/Template/systemd/CashDBAgent.service /etc/systemd/system/
cp -rf /etc/cabal/Template/systemd/EventDBAgent.service /etc/systemd/system/
cp -rf /etc/cabal/Template/systemd/PCBangDBAgent.service /etc/systemd/system/
cp -rf /etc/cabal/Template/systemd/RockAndRollITS.service /etc/systemd/system/
cp -rf /etc/cabal/Template/systemd/GlobalMgrSvr.service /etc/systemd/system/
cp -rf /etc/cabal/Template/systemd/EventMgrSvr.service /etc/systemd/system/

echo -e "${RED}==> ${NC}Copying configuration files..."
cp -rf /etc/cabal/Template/conf/Common.ini /etc/cabal/
cp -rf /etc/cabal/Template/conf/GlobalDBAgent.ini /etc/cabal/
cp -rf /etc/cabal/Template/conf/AuthDBAgent.ini /etc/cabal/
cp -rf /etc/cabal/Template/conf/CashDBAgent.ini /etc/cabal/
cp -rf /etc/cabal/Template/conf/EventDBAgent.ini /etc/cabal/
cp -rf /etc/cabal/Template/conf/PCBangDBAgent.ini /etc/cabal/
cp -rf /etc/cabal/Template/conf/RockAndRollITS.ini /etc/cabal/
cp -rf /etc/cabal/Template/conf/GlobalMgrSvr.ini /etc/cabal/
cp -rf /etc/cabal/Template/conf/EventMgrSvr.ini /etc/cabal/

echo -e "${RED}==> ${NC}Enabling new systemd services..."
systemctl daemon-reexec
systemctl enable GlobalDBAgent
systemctl enable AuthDBAgent
systemctl enable CashDBAgent
systemctl enable EventDBAgent
systemctl enable PCBangDBAgent
systemctl enable RockAndRollITS
systemctl enable GlobalMgrSvr
systemctl enable EventMgrSvr

echo -e "${RED}==> ${NC}Creating server services..."
for (( i=1; i<=$num; i++ ))
do
  leadingZero=""
  
  if [ $i -lt 10 ]
  then
    leadingZero="0"
  fi
  
  # DBAgent
  ln -sf /usr/bin/DBAgent /usr/bin/DBAgent_$leadingZero$i
  chmod 0700 /usr/bin/DBAgent_$leadingZero$i
  
  sed /etc/cabal/Template/systemd/DBAgent_x.service \
  -e "s/DBAgent_x/DBAgent_$leadingZero$i/g" \
  > /etc/systemd/system/DBAgent_$leadingZero$i.service
  
  sed /etc/cabal/Template/conf/DBAgent_x.ini \
  -e "s/dbname/DBAgent_$leadingZero$i/g" \
  > /etc/cabal/DBAgent_$leadingZero$i.ini
   
  systemctl daemon-reexec
  systemctl enable DBAgent_$leadingZero$i
  
  # PartySvr
  ln -sf /usr/bin/PartySvr /usr/bin/PartySvr_$leadingZero$i
  chmod 0700 /usr/bin/PartySvr_$leadingZero$i
  
  sed /etc/cabal/Template/systemd/PartySvr_x.service \
  -e "s/PartySvr_x/PartySvr_$leadingZero$i/g" \
  > /etc/systemd/system/PartySvr_$leadingZero$i.service
  
  cp -rf /etc/cabal/Template/conf/PartySvr_x.ini /etc/cabal/PartySvr_$leadingZero$i.ini
  
  systemctl daemon-reexec
  systemctl enable PartySvr_$leadingZero$i
  
  # ChatNode
  ln -sf /usr/bin/ChatNode /usr/bin/ChatNode_$leadingZero$i
  chmod 0700 /usr/bin/ChatNode_$leadingZero$i
  
  sed /etc/cabal/Template/systemd/ChatNode_x.service \
  -e "s/DBAgent_x/DBAgent_$leadingZero$i/g" \
  -e "s/ChatNode_x/ChatNode_$leadingZero$i/g" \
  > /etc/systemd/system/ChatNode_$leadingZero$i.service
  
  cp -rf /etc/cabal/Template/conf/ChatNode_x.ini /etc/cabal/ChatNode_$leadingZero$i.ini
  
  systemctl daemon-reexec
  systemctl enable ChatNode_$leadingZero$i
  
  # LoginSvr
  ln -sf /usr/bin/LoginSvr /usr/bin/LoginSvr_$leadingZero$i
  chmod 0700 /usr/bin/LoginSvr_$leadingZero$i
  
  sed /etc/cabal/Template/systemd/LoginSvr_x.service \
  -e "s/LoginSvr_x/LoginSvr_$leadingZero$i/g" \
  > /etc/systemd/system/LoginSvr_$leadingZero$i.service
  
  cp -rf /etc/cabal/Template/conf/LoginSvr_x.ini /etc/cabal/LoginSvr_$leadingZero$i.ini
  
  systemctl daemon-reexec
  systemctl enable LoginSvr_$leadingZero$i
  
  # AgentShop
  ln -sf /usr/bin/AgentShop /usr/bin/AgentShop_$leadingZero$i
  chmod 0700 /usr/bin/AgentShop_$leadingZero$i
  
  sed /etc/cabal/Template/systemd/AgentShop_x.service \
  -e "s/DBAgent_x/DBAgent_$leadingZero$i/g" \
  -e "s/ChatNode_x/ChatNode_$leadingZero$i/g" \
  -e "s/AgentShop_x/AgentShop_$leadingZero$i/g" \
  > /etc/systemd/system/AgentShop_$leadingZero$i.service
  
  cp -rf /etc/cabal/Template/conf/AgentShop_x.ini /etc/cabal/AgentShop_$leadingZero$i.ini
  
  systemctl daemon-reexec
  systemctl enable AgentShop_$leadingZero$i
done

echo -e "\nDone! Now create channels with: cabal_create -c [number]."
