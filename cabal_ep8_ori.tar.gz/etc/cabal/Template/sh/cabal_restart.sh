#!/bin/sh

## Functions
show_usage()
{
    echo "Usage: cabal_restart [OPTIONS]"
    echo "Restart all cabal services."
    echo ""
    echo -e "-s, --save\tbackup logs to a .tar.gz archive"
    echo -e "-d, --delete\tdelete all logs and traces"
    echo ""
    echo "By default, cabal_restart does not backup or delete logs."
}

formatted_date()
{
    date +"%Y_%m_%d"
}

## Variables
savelogs=0
deletelogs=0

## Get arguments
while [ "$1" != "" ]; do
    case $1 in
        -s | --save )
            savelogs=1
            ;;
        -d | --delete )
            deletelogs=1
            ;;
        -h | --help )
            show_usage
            exit 1
            ;;
    esac
    shift
done

## Save logs
if [ savelogs -eq 1 ]; then
    ## Create 'backups' directory if it doesn't exist
    if [ !(-d /var/log/cabal/backups) ]; then
        mkdir /var/log/cabal/backups
    fi

    tar -czf backup/${formatted_date}.tar.gz **.log
fi

## Delete logs
if [ deletelogs -eq 1 ]; then
    rm -f /var/log/cabal/*.log /var/log/cabal/*.trc
fi

## Restart the cabal services
sh cabal_stop.sh
sh cabal_start.sh
