#!/bin/sh

if [[ $EUID -ne 0 ]]; then
  echo "The cabal_config.sh script must be run as root." 1>&2
  exit 1
fi

echo -e "CABAL Server IP configuration."
echo -e "Note: this is global configuration, if you have more than 1 servers(not channels), it will be updated aswell."
echo -ne "\nEnter MSSQL server IP: "
read dbip
echo -ne "Enter MSSQL server Port(default 1433): "
read dbport

sed /etc/cabal/Template/conf/odbc.ini \
-e "s/dbip/$dbip/g" \
-e "s/dbport/$dbport/g" \
> /etc/odbc.ini

echo -ne "Enter MSSQL server User: "
read dbuser
echo -ne "Enter MSSQL server Password: "
read dbpw

sed /etc/cabal/AuthDBAgent.ini \
-e "s/.*DBId=.*/DBId=$dbuser/g" \
-e "s/.*DBPwd=.*/DBPwd=$dbpw/g" \
> /etc/cabal/AuthDBAgent.ini.tmp
mv /etc/cabal/AuthDBAgent.ini.tmp /etc/cabal/AuthDBAgent.ini

sed /etc/cabal/CashDBAgent.ini \
-e "s/.*DBId=.*/DBId=$dbuser/g" \
-e "s/.*DBPwd=.*/DBPwd=$dbpw/g" \
> /etc/cabal/CashDBAgent.ini.tmp
mv /etc/cabal/CashDBAgent.ini.tmp /etc/cabal/CashDBAgent.ini

sed /etc/cabal/EventDBAgent.ini \
-e "s/.*DBId=.*/DBId=$dbuser/g" \
-e "s/.*DBPwd=.*/DBPwd=$dbpw/g" \
> /etc/cabal/EventDBAgent.ini.tmp
mv /etc/cabal/EventDBAgent.ini.tmp /etc/cabal/EventDBAgent.ini

sed /etc/cabal/GlobalDBAgent.ini \
-e "s/.*DBId=.*/DBId=$dbuser/g" \
-e "s/.*DBPwd=.*/DBPwd=$dbpw/g" \
> /etc/cabal/GlobalDBAgent.ini.tmp
mv /etc/cabal/GlobalDBAgent.ini.tmp /etc/cabal/GlobalDBAgent.ini

sed /etc/cabal/PCBangDBAgent.ini \
-e "s/.*DBId=.*/DBId=$dbuser/g" \
-e "s/.*DBPwd=.*/DBPwd=$dbpw/g" \
> /etc/cabal/PCBangDBAgent.ini.tmp
mv /etc/cabal/PCBangDBAgent.ini.tmp /etc/cabal/PCBangDBAgent.ini

FILES=/etc/cabal/DBAgent_*.ini
for f in $FILES
do
  sed $f \
-e "s/.*DBId=.*/DBId=$dbuser/g" \
-e "s/.*DBPwd=.*/DBPwd=$dbpw/g" \
  > $f.tmp
  mv $f.tmp $f
done

echo -ne "Enter IP for players to connect: "
read cip

FILES=/etc/cabal/WorldSvr_*.ini
for f in $FILES
do
  sed $f \
  -e "s/cip/$cip/g" \
  -e "s/dbpw/$dbpw/g" \
  > $f.tmp
  mv $f.tmp $f
done

echo -e "Done! You can start server with: cabal_start"
echo -e "Quick tip(so you won't have a headache later): if you have multiple servers/channels, please change ports ;)"
echo -e "And don't forget about firewall, cheers."
