#!/bin/sh

systemctl status GlobalDBAgent
systemctl status AuthDBAgent
systemctl status CashDBAgent
systemctl status EventDBAgent
systemctl status PCBangDBAgent
systemctl status DBAgent*
systemctl status RockAndRollITS
systemctl status GlobalMgrSvr
systemctl status PartySvr*
systemctl status ChatNode*
systemctl status EventMgrSvr
systemctl status LoginSvr*
systemctl status AgentShop*
systemctl status WorldSvr*